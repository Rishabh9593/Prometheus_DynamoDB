import boto3
import datetime
import json
import re

client = boto3.client('dynamodb')

def lambda_handler(event, context):

  topic = event['Records'][0]['Sns']['TopicArn']
  subject = event['Records'][0]['Sns']['Subject']
  message = event['Records'][0]['Sns']['Message']

  print("Call from SNS topic: " + topic+", subject: ")
  
  m = re.search('^arn:aws:sns:.+?:\d+?:(.+?)-PrometheusAlerts$', topic)
  if m:
    clusterName = m.group(1)
    print("Cluster name is: " + clusterName)
  else:
    raise ValueError("Unable to find cluster name in '{0}'".format(topic))
  
  currentAlertStatus = ""
  lines = message.split("\\n")
  
  for line in lines:
    #print("Line: '{0}'".format(line))
    
    alertRe = re.search('^Alerts (.+?):$', line)
    if alertRe:
      print("RE Alert found: "+alertRe.group(1))
      currentAlertStatus = alertRe.group(1)
    
    # now just look for the alert labels
    labelRe = re.search('^ - alertname = (.+)', line)
    if(labelRe):
      currentAlertLabel = labelRe.group(1)
      print("RE Label found: {0}".format(currentAlertLabel))
      print("DynamoDB update: cluster: {0}, status: {1}, label: {2}".format(clusterName, currentAlertStatus, currentAlertLabel))
  
      # write to dynamodb, override whatever is there
      data = client.put_item(
        TableName='EKS_cluster_monitoring',
        Item={
            'cluster_name': {
              'S': clusterName
            },
            'alert_status': {
              'S': currentAlertStatus
            },
            'alert_name': {
              'S': currentAlertLabel
            },
            'last_updated': {
              'S': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            },
            'last_full_message': {
              'S': message
            }
        }
      )

  response = {
      'statusCode': 200,
      'body': 'successfully created item!',
      'headers': {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
  }
  
  return response
